from plane_main import *

if __name__ == "__main__":

    game = PlaneGame()

    game.start_game()